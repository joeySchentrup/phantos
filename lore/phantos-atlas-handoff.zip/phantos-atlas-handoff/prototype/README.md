# Prototype files

Built on a Claude Design canvas; the chart is one shared component mounted by three page shells.

- `Chart.dc.html` — the chart viewer and Dungeon Master editor. The `<script type="text/x-dc">` block at the end is plain JavaScript: data constants, pure geometry helpers, and the `Component` class with all pan/zoom, hit-testing, drag, drafting and name-tier logic. Port from here.
- `Main.dc.html` — visitor page (desktop): site header, page head, chart in reader mode.
- `DungeonMaster.dc.html` — the same page in DM mode (tool bar + desk).
- `Phone.dc.html` — visitor page at 390px: square chart, zoom 2, card below the chart, key beneath.

Markup notes: `{{name}}` is a value from `renderVals()`; `<sc-for list="{{items}}" as="x">` loops; `<sc-if value="{{flag}}">` branches; `onPointerDown="{{handler}}"` binds an event; `<x-import component-from-global-scope="Phantos.LoreCard" lore="{{…}}" to="{{…}}">` mounts the site's real LoreCard; `<dc-import name="Chart" mode="dm">` mounts Chart.dc.html with props. Styles are inline so a design tool could edit them; in the app they belong in Tailwind classes and `app.css`.
